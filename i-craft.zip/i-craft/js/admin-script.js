// JavaScript Document

jQuery(document).ready(function($) {
	//$( "#customize-info" ).after( "<div class=\"iamaze-promo\"><a href='//templatesnext.in/i-amaze/' target='_blank'>Buy I-AMAZE Pro</a></div>" );
});